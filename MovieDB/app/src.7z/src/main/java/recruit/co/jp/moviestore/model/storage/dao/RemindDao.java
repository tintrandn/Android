package recruit.co.jp.moviestore.model.storage.dao;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.util.Log;

import java.util.ArrayList;


import recruit.co.jp.moviestore.model.storage.entity.Remind;
import recruit.co.jp.moviestore.model.storage.provider.RemindProvider;

/**
 * Created by TinTHT on 2017/06/07.
 */

public class RemindDao extends Activity{

    private Context context;
    private Uri todoUri;
    // Database table
    public static final String TABLE_NAME = "remind";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_REMIMD_NAME = "remind_name";
    public static final String COLUMN_REMIND_TIME = "remind_time";

    //Create table
    private static final String DATABASE_CREATE = "create table "
            + TABLE_NAME
            + "("
            + COLUMN_ID + " integer primary key autoincrement, "
            + COLUMN_REMIMD_NAME + " text not null, "
            + COLUMN_REMIND_TIME + " text not null"
            + ");";

    public static void onCreate(SQLiteDatabase database) {
        database.execSQL(DATABASE_CREATE);
    }

    public static void onUpgrade(SQLiteDatabase database, int oldVersion,
                                 int newVersion) {
        Log.d(RemindDao.class.getName(), "Upgrading database from version "
                + oldVersion + " to " + newVersion
                + ", which will destroy all old data");
        database.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(database);
    }


    public RemindDao(Context context) {
        this.context = context;
    }
    //insert
    public void insert(ContentValues values){
        context.getContentResolver().insert(RemindProvider.CONTENT_URI, values);
        Log.d("Insert: ", String.valueOf(values));
    }
    //query all
    public ArrayList<Remind> getAllRemind(){
        ArrayList<Remind> remindList = new ArrayList<Remind>();
        Remind remind;
        String[] projection = { COLUMN_ID,COLUMN_REMIMD_NAME,COLUMN_REMIND_TIME};
        Cursor cursor = context.getContentResolver().query(RemindProvider.CONTENT_URI, projection, null, null,
                null);
        while (cursor.moveToNext()) {
            String id = cursor.getString(cursor
                    .getColumnIndex(COLUMN_ID));
            String name = cursor.getString(cursor
                    .getColumnIndexOrThrow(COLUMN_REMIMD_NAME));
            String time = cursor.getString(cursor
                    .getColumnIndexOrThrow(COLUMN_REMIND_TIME));
            Log.d("Query","_id:"+ id + "name: "+ name+ " time: " +time);
            remind = new Remind(id,name,time);
            remindList.add(remind);
        }
        return remindList;
    }
    //delete
    public int delete(String remind_id){
        return context.getContentResolver().delete(Uri.parse(RemindProvider.CONTENT_URI+"/"+remind_id), null, null);
    }
}
