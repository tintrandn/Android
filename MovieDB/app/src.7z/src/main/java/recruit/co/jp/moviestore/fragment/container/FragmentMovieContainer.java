package recruit.co.jp.moviestore.fragment.container;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;

import recruit.co.jp.moviestore.R;
import recruit.co.jp.moviestore.fragment.FragmentMovieDetail;
import recruit.co.jp.moviestore.fragment.FragmentMovieList;
import recruit.co.jp.moviestore.view.adapter.ListViewMovieAdapter;

/**
 * Created by TinTHT on 2017/06/06.
 */

public class FragmentMovieContainer extends Fragment {
    private String TAG = "MovieContainer";
    private FragmentTransaction mFragmentTransaction;
    private FragmentManager mFragmentManager;
    private FragmentMovieList firstFragment;
    private FragmentMovieDetail secondFragment;
    private static final String SHOW_MOVIE_DETAIL = "recruit.co.jp.moviestore.SHOW_MOVIE_DETAIL";
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_movie_container,container,false);
//        firstFragment = new FragmentMovieList(FragmentMovieContainer.this);
        firstFragment = new FragmentMovieList();
//        secondFragment = new FragmentMovieDetail();
        mFragmentManager = getChildFragmentManager();
        mFragmentTransaction = mFragmentManager.beginTransaction();
//        mFragmentTransaction.detach(secondFragment);
//        mFragmentTransaction.attach(firstFragment);
        mFragmentTransaction.add(R.id.fragment_container, firstFragment).commit();
        return v;
    }

private BroadcastReceiver receiver = new BroadcastReceiver() {
    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(TAG,"Receiver broadcast");
        Bundle bundle = intent.getExtras();
        String movie_name = null,movie_Id = null;
        try{
            movie_name = intent.getStringExtra("movie_name");
            movie_Id = intent.getStringExtra("movie_id");
            Log.d(TAG,"Movie name: "+ movie_name +" Movie Id: "+movie_Id);
        }catch(Exception e){
            e.printStackTrace();
        }
        secondFragment = new FragmentMovieDetail(movie_name,movie_Id);
        mFragmentTransaction = mFragmentManager.beginTransaction();
        mFragmentTransaction.replace(R.id.fragment_container, secondFragment);
        mFragmentTransaction.addToBackStack(null);
        // Commit the transaction
//        mFragmentTransaction.detach(firstFragment);
//        mFragmentTransaction.attach(secondFragment);
        mFragmentTransaction.commit();
    }
};

    @Override
    public void onResume() {
        super.onResume();
        IntentFilter filter = new IntentFilter();
        filter.addAction(SHOW_MOVIE_DETAIL);
        getActivity().registerReceiver(receiver, filter);
    }

    @Override
    public void onDetach() {
        super.onDetach();
        if (receiver != null)
        getActivity().unregisterReceiver(receiver);
        receiver = null;
    }
}
