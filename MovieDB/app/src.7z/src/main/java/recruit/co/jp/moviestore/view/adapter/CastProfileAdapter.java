package recruit.co.jp.moviestore.view.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.NetworkImageView;

import java.util.ArrayList;

import recruit.co.jp.moviestore.R;
import recruit.co.jp.moviestore.model.Cast;
import recruit.co.jp.moviestore.network.api.BitmapLruCache;
import recruit.co.jp.moviestore.util.CustomRequestQueue;

/**
 * Created by TinTHT on 2017/06/06.
 */

public class CastProfileAdapter extends RecyclerView.Adapter<CastProfileAdapter.ViewHolder> {

    private static final String TAG = "CastProfileAdapter";
    private Context mContext;
    private ArrayList<Cast> mCastArrayList;

    public CastProfileAdapter(ArrayList<Cast> casts) {
        this.mCastArrayList = casts;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private NetworkImageView cast_profile;
        private TextView name;

        public ViewHolder(View view) {
            super(view);
            mContext = view.getContext();
            cast_profile = (NetworkImageView) view.findViewById(R.id.cast_profile);
            name = (TextView) view.findViewById(R.id.cast_name);
        }
    }
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Log.d(TAG,"Create Cast Profile View");
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.cast_profile_item, parent, false);

        return new CastProfileAdapter.ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        final Cast cast = mCastArrayList.get(position);
        Log.d(TAG,"onBind "+cast.getName());
        // Instantiate the RequestQueue.
        CustomRequestQueue requestQueue = new CustomRequestQueue(mContext);
        ImageLoader.ImageCache imageCache = new BitmapLruCache();
        ImageLoader imageLoader = new ImageLoader(requestQueue.getRequestQueue(), imageCache);
        //Image URL - This can point to any image file supported by Android
        final String url = "https://image.tmdb.org/t/p/w640/";
//        final String url = "https://image.tmdb.org/t/p/w533_and_h300_bestv2/";
        holder.cast_profile.setImageUrl(url+cast.getImage(),imageLoader);
        holder.name.setText(cast.getName());
    }

    @Override
    public int getItemCount() {
        return mCastArrayList.size();
    }
}
