package recruit.co.jp.moviestore.model;

/**
 * Created by TinTHT on 2017/06/05.
 */
public class RemindDrawerItem {
    private boolean showNotify;
    private String title;
    private String time;

    public RemindDrawerItem(){

    }

    public RemindDrawerItem(boolean showNotify, String title, String time){
        this.showNotify = showNotify;
        this.title = title;
        this.time = time;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public boolean isShowed(){
        return  showNotify;
    }

    public void setShowNotify(boolean isShow){
        this.showNotify = isShow;
    }

    public String getTitle(){
        return title;
    }

    public void setTitle(String title){
        this.title = title;
    }
}

