package recruit.co.jp.moviestore.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.HttpAuthHandler;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import recruit.co.jp.moviestore.R;

/**
 * Created by TinTHT on 2017/06/02.
 */

public class FragmentAbout extends Fragment {
    private WebView about_web_view;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_about,container,false);
        about_web_view = (WebView) v.findViewById(R.id.about_web_view);
        //add proxy authentication
        about_web_view.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedHttpAuthRequest(WebView view, HttpAuthHandler handler, String host, String realm) {
                handler.proceed("tintht", "X@thu1mat");
            }
        });

        //add to get the mobile web version
        about_web_view.getSettings().setJavaScriptEnabled(true);
        about_web_view.getSettings().setUserAgentString("Mozilla/5.0 (iPhone; U; CPU like Mac OS X; en) AppleWebKit/420+ (KHTML, like Gecko) Version/3.0 Mobile/1A543a Safari/419.3");
//        about_web_view.loadUrl("https://www.themoviedb.org/about/our-history");
        about_web_view.loadUrl("https://www.themoviedb.org/documentation/api");
        return v;
    }
}
