package recruit.co.jp.moviestore.fragment;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.ContentValues;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;

import java.util.ArrayList;
import java.util.Calendar;

import recruit.co.jp.moviestore.R;
import recruit.co.jp.moviestore.model.Cast;
import recruit.co.jp.moviestore.model.storage.dao.RemindDao;
import recruit.co.jp.moviestore.network.api.JSonParse;
import recruit.co.jp.moviestore.view.adapter.CastProfileAdapter;

/**
 * Created by TinTHT on 2017/06/06.
 */

public class FragmentMovieDetail extends Fragment {
    private Context mContext;
    private JSonParse.Cast_Id mCast_id;
    private TextView remindTime;
    private Calendar mCalendar;
    private String mMovieName, mMovieID;
    private static String mYear, mMonth, mDay, mHour, mMinute;
    private static boolean mSetTime;

    public FragmentMovieDetail() {

    }

    public FragmentMovieDetail(String mMovieName, String mMovieID) {
        this.mMovieName = mMovieName;
        this.mMovieID = mMovieID;
    }

    @Nullable
    @Override

    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_movie_detail,container,false);
        mContext = v.getContext();
        ActionBar actionBar = ((AppCompatActivity)getActivity()).getSupportActionBar();
        if (actionBar!= null) {
            Log.d("MovieDetail","Set title" +mMovieName);
            actionBar.setTitle(mMovieName);
        }
        remindTime = (TextView) v.findViewById(R.id.movie_detail_remind_time) ;
        Button remindButton = (Button) v.findViewById(R.id.movie_detail_btn_remind);
        final RecyclerView recyclerView = (RecyclerView) v.findViewById(R.id.movie_detail_cast_profile);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        recyclerView.setLayoutManager(linearLayoutManager);
        JSonParse jSonParse = new JSonParse();
        mCast_id = JSonParse.startParse_Cast("321612");
        ArrayList<Cast> castArrayList = mCast_id.getmCastArrayList();
        ArrayList<Cast> castList = new ArrayList<>();
        for (int i=0;i<10;i++){
            castList.add(castArrayList.get(i));
        }
        CastProfileAdapter castProfileAdapter = new CastProfileAdapter(castList);
        recyclerView.setAdapter(castProfileAdapter);

        mCalendar = Calendar.getInstance();
        final TimePickerDialog.OnTimeSetListener time = new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                mHour = String.valueOf(hourOfDay);
                mMinute = String.valueOf(minute);
                Log.d("Set remind time","Hour "+mHour+" Minute "+mMinute);
                if (mSetTime) {
                    showRemindTime();
                    mSetTime = false;
                }
            }
        };
        final DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener(){
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                mDay = String.valueOf(dayOfMonth);
                mMonth = String.valueOf(month);
                mYear = String.valueOf(year);
                Log.d("Set remind date","Year "+mYear+" Month "+mMonth+" Day "+mDay);
                if (!mSetTime) {
                    mSetTime = true;
                    updateTime();
                }
            }

            private void updateTime() {
                mCalendar = Calendar.getInstance();
                new TimePickerDialog(mContext, time, mCalendar
                        .get(Calendar.HOUR_OF_DAY),mCalendar.get(Calendar.MINUTE),false).show();
            }
        };

        remindButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mSetTime = false;
                new DatePickerDialog(mContext, date, mCalendar
                        .get(Calendar.YEAR), mCalendar.get(Calendar.MONTH),
                        mCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });
        return v;
    }

    private void showRemindTime() {
        String time = mYear+"/"+mMonth+"/"+mDay+" "+mHour+":"+mMinute;
        remindTime.setText(time);
        remindTime.setVisibility(View.VISIBLE);
        //save data to remind.db database
        ContentValues values = new ContentValues();
        values.put(RemindDao.COLUMN_REMIMD_NAME, mMovieName);
        values.put(RemindDao.COLUMN_REMIND_TIME, time);
        RemindDao remindDao = new RemindDao(mContext);
        remindDao.insert(values);
    }
}
