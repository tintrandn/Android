package recruit.co.jp.moviestore.view.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.Collections;
import java.util.List;

import recruit.co.jp.moviestore.R;
import recruit.co.jp.moviestore.model.RemindDrawerItem;

/**
 * Created by TinTHT on 2017/05/31.
 */

public class RemindDrawerAdapter extends RecyclerView.Adapter <RemindDrawerAdapter.MyViewHolder> {

    List<RemindDrawerItem> remind = Collections.emptyList();
    private LayoutInflater inflater;
    private Context context;

    public RemindDrawerAdapter( Context context, List<RemindDrawerItem> remind) {
        this.remind = remind;
        inflater = LayoutInflater.from(context);
        this.context = context;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView remind_title;
        TextView remind_time;


        public MyViewHolder(View itemView) {
            super(itemView);
            remind_title = (TextView) itemView.findViewById(R.id.remind_title);
            remind_time = (TextView)itemView.findViewById(R.id.remind_time);
        }

    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.remind_drawer_row, parent, false);
        MyViewHolder holder = new MyViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(final MyViewHolder holder, int position) {
        RemindDrawerItem current = remind.get(position);
        holder.remind_title.setText(current.getTitle());
        holder.remind_time.setText(current.getTime());
    }

    @Override
    public int getItemCount() {
        return remind.size();
    }
}
