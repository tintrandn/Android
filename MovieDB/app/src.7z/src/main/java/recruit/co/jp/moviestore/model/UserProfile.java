package recruit.co.jp.moviestore.model;

/**
 * Created by TinTHT on 2017/06/01.
 */

public class UserProfile {
    //private variables
    int _id;
    byte[] user_image;
    String user_name;
    String user_mail;
    String user_birthday;
    String user_gender;


    // Empty constructor
    public UserProfile(){

    }

    public UserProfile(int _id, byte[] user_image, String user_name, String user_mail, String user_birthday, String user_gender) {
        this._id = _id;
        this.user_image = user_image;
        this.user_name = user_name;
        this.user_mail = user_mail;
        this.user_birthday = user_birthday;
        this.user_gender = user_gender;
    }

    public byte[] getUser_image() {
        return user_image;
    }

    public void setUser_image(byte[] user_image) {
        this.user_image = user_image;
    }

    public int get_id() {
        return _id;
    }

    public void set_id(int _id) {
        this._id = _id;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getUser_mail() {
        return user_mail;
    }

    public void setUser_mail(String user_mail) {
        this.user_mail = user_mail;
    }

    public String getUser_birthday() {
        return user_birthday;
    }

    public void setUser_birthday(String user_birthday) {
        this.user_birthday = user_birthday;
    }

    public String getUser_gender() {
        return user_gender;
    }

    public void setUser_gender(String user_gender) {
        this.user_gender = user_gender;
    }
}
