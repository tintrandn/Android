package recruit.co.jp.moviestore.view.adapter;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.NetworkImageView;

import recruit.co.jp.moviestore.R;
import recruit.co.jp.moviestore.model.Movie;
import recruit.co.jp.moviestore.network.api.BitmapLruCache;
import recruit.co.jp.moviestore.util.CustomRequestQueue;

/**
 * Created by TinTHT on 2017/06/02.
 */

public class GridViewMovieAdapter extends RecyclerView.Adapter<GridViewMovieAdapter.ViewHolder> {

    private static final String TAG = "GridViewApdater";
    private Context mContext;
    private ArrayList<Movie> moviesList;

    public GridViewMovieAdapter(ArrayList<Movie> moviesList) {
        this.moviesList = moviesList;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView title;
        private NetworkImageView poster;


        public ViewHolder(View view) {
            super(view);
            mContext = view.getContext();
            title = (TextView) view.findViewById(R.id.movie_title);
            poster = (NetworkImageView) view.findViewById(R.id.movies_poster);
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Log.d(TAG,"Create List View");
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.grid_movie_row, parent, false);

        return new ViewHolder(itemView);
    }
    //display the movie information
    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        final Movie movie = moviesList.get(position);
        Log.d(TAG,"onBind "+movie.getTitle());
        // Instantiate the RequestQueue.
        CustomRequestQueue requestQueue = new CustomRequestQueue(mContext);
        ImageLoader.ImageCache imageCache = new BitmapLruCache();
        ImageLoader imageLoader = new ImageLoader(requestQueue.getRequestQueue(), imageCache);
        //Image URL - This can point to any image file supported by Android
//        final String url = "https://image.tmdb.org/t/p/w640/";
        final String url = "https://image.tmdb.org/t/p/w533_and_h300_bestv2/";
        holder.poster.setImageUrl(url+movie.getImage(),imageLoader);

        holder.title.setText(movie.getTitle());

    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position, List<Object> payloads) {

        super.onBindViewHolder(holder, position, payloads);
    }

    @Override
    public int getItemCount() {
        return moviesList.size();
    }

}
