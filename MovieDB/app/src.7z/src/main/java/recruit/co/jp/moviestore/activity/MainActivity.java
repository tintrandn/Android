package recruit.co.jp.moviestore.activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.Toast;


import java.util.ArrayList;

import recruit.co.jp.moviestore.R;
import recruit.co.jp.moviestore.fragment.FragmentAbout;
import recruit.co.jp.moviestore.fragment.FragmentFavourite;
import recruit.co.jp.moviestore.fragment.FragmentDrawer;
import recruit.co.jp.moviestore.fragment.FragmentRemindShowAll;
import recruit.co.jp.moviestore.fragment.container.FragmentSettingContainer;
import recruit.co.jp.moviestore.fragment.container.FragmentMovieContainer;
import recruit.co.jp.moviestore.model.Movie;
import recruit.co.jp.moviestore.network.api.JSonParse;
import recruit.co.jp.moviestore.view.adapter.ViewPagerAdapter;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private Toolbar mToolbar;
    private FragmentDrawer mFragmentDrawer;
    private TabLayout mTabLayout;
    private ViewPager mViewPager;
    private ViewPagerAdapter mViewPagerAdapter;
    private RelativeLayout mRelativeLayout;
    private ArrayList<Movie> mMovieArrayList;
    private JSonParse.Page page;
    private int pageNumber = 1;
    private static final String DEBUG_TAG = "NetworkStatusExample";
//    private static final String SHOW_ALL_REMIND = "recruit.co.jp.moviestore.SHOW_ALL_REMIND";
    private String [] tabTitle = {
            "Movies",
            "Favourite",
            "Setting",
            "About"
    };

    private int[] tabIcon = {
            R.mipmap.ic_home,
            R.mipmap.ic_favorite,
            R.mipmap.ic_settings,
            R.mipmap.ic_info
    };

//    private BroadcastReceiver receiver = new BroadcastReceiver() {
//        @Override
//        public void onReceive(Context context, Intent intent) {
//            Log.d(TAG,"Receiver broadcast");
//        }
//    };

    @Override
    protected void onResume() {
//        IntentFilter filter = new IntentFilter();
//        filter.addAction(SHOW_ALL_REMIND);
//        registerReceiver(receiver, filter);
        super.onResume();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mRelativeLayout = (RelativeLayout) findViewById(R.id.splash_screen);
        ConnectivityManager connMgr = (ConnectivityManager)
                getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = connMgr.getActiveNetworkInfo();
        //if the device connect to wifi or mobile network
        if (activeNetwork != null) {
            Log.d(TAG,"Network type: "+ activeNetwork.getTypeName());
            new MyTask().execute();
        }
        else{
            Toast.makeText(this, "No network connection..", Toast.LENGTH_LONG).show();
            mRelativeLayout.setVisibility(View.GONE);
        }
//        ActionBar actionBar = getSupportActionBar();
        mToolbar = (Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        mFragmentDrawer = (FragmentDrawer)
                getSupportFragmentManager().findFragmentById(R.id.fragment_navigation_drawer);
        mFragmentDrawer.setUp(R.id.fragment_navigation_drawer, (DrawerLayout) findViewById(R.id.drawer_layout), mToolbar);
        mViewPager = (ViewPager)findViewById(R.id.view_page_context);
        createViewPager(mViewPager);
        mTabLayout = (TabLayout)findViewById(R.id.tabLayout);
        mTabLayout.setupWithViewPager(mViewPager);
        createTabIcon();
    }

    //Async task call API and save data to sqlite
    class MyTask extends AsyncTask<Integer, Integer, String> {
        @Override
        protected String doInBackground(Integer... params) {
            //pasre API
            JSonParse jsonParse = new JSonParse();
            for (;pageNumber<3;pageNumber++){
                page = jsonParse.startParse_Popular(String.valueOf(pageNumber));
                Log.d(TAG,"Start parse Popular: "+ String.valueOf(pageNumber));
                //Save to Sqllite
                //init data
                mMovieArrayList = page.get_movieList();
//                PopularMovieDatabaseHandler db = new PopularMovieDatabaseHandler(getApplication());
//                for (Movie movie:mMovieArrayList){
//                    db.addMovie(movie);
//                }
//                // Reading all movie
//                Log.d("Reading: ", "Reading all Movies..");
//                List<Movie> movieList = db.getAllMovies();
//                for (Movie movie : movieList) {
//                    String log = "_id: "+movie.get_id()
//                            +" ,Image: " + movie.getImage()
//                            +" ,Title: " + movie.getTitle()
//                            +" ,Release day: " + movie.getRelease_day()
//                            +" ,Rate: " + movie.getRate()
//                            +" ,Adult: " + movie.getAdult()
//                            +" ,Overview: " + movie.getOverview()
//                            +" ,Favourite: " + String.valueOf(movie.getFavourite())
//                            +" ,MovieID: " + String.valueOf(movie.getMovie_Id());
//                    // Writing Contacts to log
//                    Log.d("Movie: ", log);
//                }
            }
            return "Task Completed.";
        }
        @Override
        protected void onPostExecute(String result) {
            mRelativeLayout.setVisibility(View.GONE);
        }
        @Override
        protected void onPreExecute() {

        }
        @Override
        protected void onProgressUpdate(Integer... values) {

        }
    }
    //If not recreate Tab Icon, Tab Icon will not apprear
    private void createTabIcon() {
        for (int i = 0; i < mTabLayout.getTabCount(); i++) {
            mTabLayout.getTabAt(i).setIcon(tabIcon[i]);
        }
        //custom favourite tab
        View view = LayoutInflater.from(this).inflate(R.layout.custom_tablayout, null);
        mTabLayout.getTabAt(1).setCustomView(view);
    }
    //===================================================
    private void createViewPager(ViewPager viewPager) {
        mViewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager());
//        mViewPagerAdapter.addFrag(new MovieList(), tabTitle[0]);
        mViewPagerAdapter.addFrag(new FragmentMovieContainer(),tabTitle[0]);
        mViewPagerAdapter.addFrag(new FragmentFavourite(), tabTitle[1]);
        mViewPagerAdapter.addFrag(new FragmentSettingContainer(), tabTitle[2]);
        mViewPagerAdapter.addFrag(new FragmentAbout(), tabTitle[3]);
        viewPager.setAdapter(mViewPagerAdapter);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_movie) {
            Log.d(TAG,"click Movie");
            mViewPager.setCurrentItem(0);
            return true;
        }
        if (id == R.id.action_favourite) {
            Log.d(TAG,"click Favourite");
            mViewPager.setCurrentItem(1);
            return true;
        }
        if (id == R.id.action_settings) {
            Log.d(TAG,"click Setting");
            mViewPager.setCurrentItem(2);
            return true;
        }
        if (id == R.id.action_about) {
            Log.d(TAG,"click About");
            mViewPager.setCurrentItem(3);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
//        super.onBackPressed();
    }
}
