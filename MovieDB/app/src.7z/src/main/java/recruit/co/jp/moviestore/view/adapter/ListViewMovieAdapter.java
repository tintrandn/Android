package recruit.co.jp.moviestore.view.adapter;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.Network;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HttpStack;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.NetworkImageView;
import com.android.volley.toolbox.Volley;

import recruit.co.jp.moviestore.R;
import recruit.co.jp.moviestore.model.Movie;
import recruit.co.jp.moviestore.network.api.BitmapLruCache;
import recruit.co.jp.moviestore.util.CustomRequestQueue;

import static android.icu.lang.UCharacter.GraphemeClusterBreak.L;

/**
 * Created by TinTHT on 2017/06/02.
 */

public class ListViewMovieAdapter extends RecyclerView.Adapter<ListViewMovieAdapter.ViewHolder> {

    private static final String TAG = "ListViewApdater";
    private ArrayList<Movie> moviesList;
    private Context mContext;
    // Default maximum disk usage in bytes
    private static final int DEFAULT_DISK_USAGE_BYTES = 25 * 1024 * 1024;
    private static final String IMAGE_API = "http://image.tmdb.org/t/p/w640/";

    // Default cache folder name
    private static final String DEFAULT_CACHE_DIR = "photos";
    private ICallback mICallback;
    private static Movie movie;
    private static final String SHOW_MOVIE_DETAIL = "recruit.co.jp.moviestore.SHOW_MOVIE_DETAIL";

    public ListViewMovieAdapter(ArrayList<Movie> moviesList,ICallback iCallback) {
        this.moviesList = moviesList;
        this.mICallback = iCallback;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
            private TextView title, release_day, rating, overview;
            private NetworkImageView poster;
            private ImageView adult;
            private ImageView start;
            private ImageView selected;


            public ViewHolder(View view) {
                super(view);
                mContext = view.getContext();
                title = (TextView) view.findViewById(R.id.movie_title);
                release_day = (TextView) view.findViewById(R.id.movie_release_day);
                rating = (TextView) view.findViewById(R.id.movie_rating);
                overview = (TextView) view.findViewById(R.id.movie_description);
                poster = (NetworkImageView) view.findViewById(R.id.movies_poster);
                adult = (ImageView) view.findViewById(R.id.movie_adult);
                start = (ImageView) view.findViewById(R.id.movie_like) ;
                selected = (ImageView) view.findViewById(R.id.movie_selected);
                view.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
//                        mICallback.clickItem(getAdapterPosition());
                        Intent show_movie_detail = new Intent();
                        Bundle bundle = new Bundle();
                        bundle.putString("movie_name",movie.getTitle());
                        bundle.putString("movie_id",String.valueOf(movie.getMovie_Id()));
                        show_movie_detail.putExtras(bundle);
                        show_movie_detail.setAction(SHOW_MOVIE_DETAIL);
                        mContext.sendBroadcast(show_movie_detail);
                        Log.d(TAG,"Send broadcast "+SHOW_MOVIE_DETAIL);
                    }
                });
            }
        }
    // Custom RequestQueue
    private static RequestQueue newRequestQueue(Context context) {
        // define cache folder
        File rootCache = context.getExternalCacheDir();
        if (rootCache == null) {
            rootCache = context.getCacheDir();
        }

        File cacheDir = new File(rootCache, DEFAULT_CACHE_DIR);
        cacheDir.mkdirs();

        HttpStack stack = new HurlStack();
        Network network = new BasicNetwork(stack);
        DiskBasedCache diskBasedCache = new DiskBasedCache(cacheDir, DEFAULT_DISK_USAGE_BYTES);
        RequestQueue queue = new RequestQueue(diskBasedCache, network);
        queue.start();
        return queue;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Log.d(TAG,"Create List View");
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_movie_row, parent, false);

        return new ViewHolder(itemView);
    }
    //display the movie information
    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        movie = moviesList.get(position);
        Log.d(TAG,movie.getTitle());
        // Instantiate the RequestQueue.
        CustomRequestQueue requestQueue = new CustomRequestQueue(mContext);
        ImageLoader.ImageCache imageCache = new BitmapLruCache();
        ImageLoader imageLoader = new ImageLoader(requestQueue.getRequestQueue(), imageCache);
        //Image URL - This can point to any image file supported by Android
        final String url = "https://image.tmdb.org/t/p/w640/";
        holder.poster.setImageUrl(url+movie.getImage(),imageLoader);

        holder.title.setText(movie.getTitle());
        holder.release_day.setText(movie.getRelease_day());
        holder.rating.setText(movie.getRate());
        holder.overview.setText(movie.getOverview());
        if(!movie.getAdult()) holder.adult.setVisibility(View.INVISIBLE);
        //handler add to favourite list
        if(!movie.getSelected()){
            holder.start.setVisibility(View.VISIBLE);
            holder.selected.setVisibility(View.GONE);
        }
        else{
            holder.start.setVisibility(View.GONE);
            holder.selected.setVisibility(View.VISIBLE);
        }
        holder.start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                movie.setSelected(true);
                notifyDataSetChanged();
            }
        });
        holder.selected.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                movie.setSelected(false);
                notifyDataSetChanged();
            }
        });
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position, List<Object> payloads) {

        super.onBindViewHolder(holder, position, payloads);
    }

    @Override
    public int getItemCount() {
        return moviesList.size();
    }

    public interface ICallback{
        void clickItem(int position);
    }
}
