package recruit.co.jp.moviestore.view.adapter;

import android.content.Context;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.NetworkImageView;

import java.util.ArrayList;

import recruit.co.jp.moviestore.R;
import recruit.co.jp.moviestore.model.storage.dao.RemindDao;
import recruit.co.jp.moviestore.model.storage.entity.Remind;
import recruit.co.jp.moviestore.network.api.BitmapLruCache;
import recruit.co.jp.moviestore.util.CustomRequestQueue;

/**
 * Created by TinTHT on 2017/06/07.
 */

public class RemindShowAllAdapter extends RecyclerView.Adapter<RemindShowAllAdapter.ViewHolder> {

    private static final String TAG = "RemindShowAllAdapter";
    private Context mContext;
    private ArrayList<Remind> mRemindArrayList;
    private Remind mRemind;

    public RemindShowAllAdapter(ArrayList<Remind> mRemindArrayList) {
        this.mRemindArrayList = mRemindArrayList;
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView remind_tilte, remind_time;
        private NetworkImageView remind_image;

        public ViewHolder(View view) {
            super(view);
            mContext = view.getContext();
            remind_image = (NetworkImageView) view.findViewById(R.id.remind_net_image);
            remind_tilte = (TextView) view.findViewById(R.id.remind_show_all_name);
            remind_time = (TextView) view.findViewById(R.id.remind_show_all_time);
//            view.setOnLongClickListener(new View.OnLongClickListener() {
//                @Override
//                public boolean onLongClick(View v) {
//                    Log.d(TAG,"Remind item click");
//                    AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
//                    // add a list
//                    String[] button = {"Delete", "Cancel"};
//                    builder.setItems(button, new DialogInterface.OnClickListener() {
//                        @Override
//                        public void onClick(DialogInterface dialog, int which) {
//                            switch (which) {
//                                case 0: // delete
//                                    AlertDialog.Builder deleteAlertBuilder = new AlertDialog.Builder(mContext);
//                                    deleteAlertBuilder.setTitle("Are you sure to delete?");
//
//                                    // set dialog message
//                                    deleteAlertBuilder
//                                            .setCancelable(false)
//                                            .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
//                                                public void onClick(DialogInterface dialog, int id) {
//                                                    remove_remind_item();
//                                                }
//                                            })
//                                            .setNegativeButton("No", new DialogInterface.OnClickListener() {
//                                                public void onClick(DialogInterface dialog, int id) {
//                                                    dialog.cancel();
//                                                }
//                                            });
//                                    // create alert dialog
//                                    AlertDialog deleteDialog = deleteAlertBuilder.create();
//                                    // show it
//                                    deleteDialog.show();
//
//                                case 1: // cancel
//                                    dialog.dismiss();
//                            }
//                        }
//                    });

// create and show the alert dialog
//                    AlertDialog dialog = builder.create();
//                    dialog.show();
//                    return false;
//                }
//            });
        }
    }

    private void remove_remind_item(int position) {
        RemindDao remindDao = new RemindDao(mContext);
        //delete 1 row success
        if (remindDao.delete(mRemind.get_id()) == 1) {
            Log.d("Delete remind"," Success");
        }
        mRemindArrayList.remove(position);
        notifyDataSetChanged();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.remind_item_row, parent, false);

        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        mRemind = mRemindArrayList.get(position);
//        // Instantiate the RequestQueue.
//        CustomRequestQueue requestQueue = new CustomRequestQueue(mContext);
//        ImageLoader.ImageCache imageCache = new BitmapLruCache();
//        ImageLoader imageLoader = new ImageLoader(requestQueue.getRequestQueue(), imageCache);
        //Image URL - This can point to any image file supported by Android
//        final String url = "https://image.tmdb.org/t/p/w640/";
//        final String url = "https://image.tmdb.org/t/p/w533_and_h300_bestv2/";
//        holder.remind_image.setImageUrl(url+remind.getImage(),imageLoader);
        holder.remind_tilte.setText(mRemind.getRemind_name());
        holder.remind_time.setText(mRemind.getRemind_time());

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Log.d(TAG,"Remind item click");
                AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
                // add a list
                String[] button = {"Delete", "Cancel"};
                builder.setItems(button, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0: // delete
                                AlertDialog.Builder deleteAlertBuilder = new AlertDialog.Builder(mContext);
                                deleteAlertBuilder.setTitle("Are you sure to delete?");

                                // set dialog message
                                deleteAlertBuilder
                                        .setCancelable(false)
                                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int id) {
                                                remove_remind_item(position);
                                            }
                                        })
                                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int id) {
                                                dialog.cancel();
                                            }
                                        });
                                // create alert dialog
                                AlertDialog deleteDialog = deleteAlertBuilder.create();
                                // show it
                                deleteDialog.show();

                            case 1: // cancel
                                dialog.dismiss();
                        }
                    }
                });

                // create and show the alert dialog
                AlertDialog dialog = builder.create();
                dialog.show();
                return false;
            }
        });
    }

    @Override
    public int getItemCount() {
        return mRemindArrayList.size();
    }

}
