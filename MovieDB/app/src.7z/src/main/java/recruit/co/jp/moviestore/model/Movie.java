package recruit.co.jp.moviestore.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by TinTHT on 2017/05/24.
 */

public class Movie {
    @SerializedName("poster_path")
    private String image;
    @SerializedName("title")
    private String title;
    @SerializedName("release_date")
    private String release_day;
    @SerializedName("overview")
    private String overview;
    @SerializedName("vote_average")
    private float rate;
    @SerializedName("adult")
    private boolean adult;
    @SerializedName("id")
    private int movie_Id;

    private boolean selected;

    public Movie() {

    }

    public Movie(String title, String release_day, String overview, float rate, boolean adult) {
        this.title = title;
        this.release_day = release_day;
        this.overview = overview;
        this.rate = rate;
        this.adult = adult;
    }

    public Movie(String image, String title, String release_day , String overview, float rate, boolean adult, int movie_Id) {
        this.image = image;
        this.title = title;
        this.release_day = release_day;
        this.overview = overview;
        this.rate = rate;
        this.adult = adult;
        this.movie_Id = movie_Id;
        selected = false;
    }
    //===========================================================
    public String getImage() {
        return image;
    }
    public void setImage(String image) {
        this.image = image;
    }
    //===========================================================
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    //===========================================================
    public String getRelease_day() {
        return release_day;
    }
    public void setRelease_day(String release_day) {
        this.release_day = release_day;
    }
    //===========================================================
    public String getOverview() {
        return overview;
    }
    public void setOverview(String overview) {
        this.overview = overview;
    }
    //===========================================================
    public String getRate() {
        return Float.toString(rate);
    }
    public void setRate(float rate) {
        this.rate = rate;
    }
    //===========================================================
    public int getMovie_Id() {
        return movie_Id;
    }
    public void setMovie_Id(int movie_Id) {
        this.movie_Id = movie_Id;
    }
    //===========================================================
    public boolean getAdult() {
        return adult;
    }
    public void setAdult(boolean adult) {
        this.adult = adult;
    }
    //===========================================================
    public boolean getSelected() {
        return selected;
    }
    public void setSelected(boolean selected) {
        this.selected = selected;
    }
}
