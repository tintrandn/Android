package recruit.co.jp.moviestore.activity;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.AppCompatRadioButton;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;

import recruit.co.jp.moviestore.R;
import recruit.co.jp.moviestore.model.UserProfile;


/**
 * Created by TinTHT on 2017/05/31.
 */

public class ProfileEdit extends Activity{
    private static final String TAG = "ProfileEdit";
    private ImageView profile_picture;
    private Button btn_profile_cancel;
    private Button btn_profile_done;
    private EditText edt_user_name;
    private EditText edt_user_mail;
    private EditText edt_user_birthday;
    //    private RadioGroup radioGroup;
    private AppCompatRadioButton radio_male;
    private AppCompatRadioButton radio_female;
    private Calendar myCalendar;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private String image_path;
    private UserProfile user;
    static final int REQUEST_IMAGE_CAPTURE = 1;
    static final int SELECT_GALLERY = 2;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);
        sharedPreferences = getSharedPreferences("profile", MODE_PRIVATE);
        editor = sharedPreferences.edit();
        edt_user_name = (EditText)findViewById(R.id.edt_user_name);
        edt_user_mail = (EditText)findViewById(R.id.edt_user_mail);
        edt_user_birthday = (EditText)findViewById(R.id.edt_user_birthday);
        btn_profile_cancel = (Button)findViewById(R.id.btn_profile_cancel);
        btn_profile_done = (Button)findViewById(R.id.btn_profile_done);
        radio_male = (AppCompatRadioButton) findViewById(R.id.radio_male);
        radio_female = (AppCompatRadioButton)findViewById(R.id.radio_female);
        btn_profile_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        btn_profile_done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG,"Done click");
                editor.putString("image",image_path);
                editor.putString("name",String.valueOf(edt_user_name.getText()));
                editor.putString("mail",String.valueOf(edt_user_mail.getText()));
                editor.putString("birthday",String.valueOf(edt_user_birthday.getText()));
                editor.putString("gender",radio_male.isChecked()? "Male":"Female");
                editor.commit();
                finish();
            }
        });
        profile_picture = (ImageView) findViewById(R.id.profile_picture);

        String profile_img_path = sharedPreferences.getString("image",null);
        String gender = sharedPreferences.getString("gender",null);
        if (profile_img_path!=null){
            File imgFile = new  File(profile_img_path);
            Bitmap myBitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());
            profile_picture.setImageBitmap(myBitmap);
        }
        edt_user_name.setText(sharedPreferences.getString("name","Recuilt"));
        edt_user_mail.setText(sharedPreferences.getString("mail","sample@recuit.com"));
        edt_user_birthday.setText(sharedPreferences.getString("birthday","01/01/2017"));
        if(gender.equals("Male")){
            radio_male.setChecked(true);
    }
        else
    {
        radio_female.setChecked(true);
    }

        //set datepick birthday
        myCalendar = Calendar.getInstance();

        final DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateBrithday();
            }

            private void updateBrithday() {
                String myFormat = "MM/dd/yyyy"; //In which you need put here
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
                edt_user_birthday.setText(sdf.format(myCalendar.getTime()));
            }
        };
        edt_user_birthday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(ProfileEdit.this, date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });
        //=======================================================
        //profile picture listener
        profile_picture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectImage();
            }
        });
    }

    //select image
    private void selectImage(){
        final String[] items = {"Gallery","Camera"};
        AlertDialog.Builder builder = new AlertDialog.Builder(ProfileEdit.this);
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                if (items[item].equals("Camera")) {
                    //cameraIntent();
                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(intent, REQUEST_IMAGE_CAPTURE);
                } else if (items[item].equals("Gallery")) {
//                            galleryIntent();
                    Intent intent = new Intent();
                    intent.setType("image/*");
                    intent.setAction(Intent.ACTION_GET_CONTENT);//
                    startActivityForResult(Intent.createChooser(intent, "Select File"),SELECT_GALLERY);
                }
                dialog.dismiss();
            }
        });
        builder.show();
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == SELECT_GALLERY)
                onSelectFromGalleryResult(data);
            else if (requestCode == REQUEST_IMAGE_CAPTURE)
                onCaptureImageResult(data);
        }
    }
    //set to display image
    private void onSelectFromGalleryResult(Intent data) {
        Bitmap profile =null;
        if (data != null) {
            try {
                profile = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), data.getData());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        // CALL THIS METHOD TO GET THE URI FROM THE BITMAP
        Uri tempUri = getImageUri(getApplicationContext(), profile);

        // CALL THIS METHOD TO GET THE ACTUAL PATH
        image_path = getRealPathFromURI(tempUri);
        profile_picture.setImageBitmap(profile);

    }
    //set to display image
    private void onCaptureImageResult(Intent data) {
        File folder = new File(Environment.getExternalStorageDirectory() +
                File.separator + "MovieStore/Profile");
        boolean success = true;
        if (!folder.exists()) {
            success = folder.mkdirs();
        }
        Bitmap profile = (Bitmap) data.getExtras().get("data");
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        //profile.compress(Bitmap.CompressFormat.JPEG, 90, bytes);
        File destination = new File(folder.getPath(),
                System.currentTimeMillis() + ".jpg");
        FileOutputStream fo;
        try {
            destination.createNewFile();
            fo = new FileOutputStream(destination);
            fo.write(bytes.toByteArray());
            fo.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        // CALL THIS METHOD TO GET THE URI FROM THE BITMAP
        Uri tempUri = getImageUri(getApplicationContext(), profile);

        // CALL THIS METHOD TO GET THE ACTUAL PATH
        image_path = getRealPathFromURI(tempUri);
        profile_picture.setImageBitmap(profile);
    }
    public Uri getImageUri(Context inContext, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(inContext.getContentResolver(), inImage, "Title", null);
        return Uri.parse(path);
    }

    public String getRealPathFromURI(Uri uri) {
        Cursor cursor = getContentResolver().query(uri, null, null, null, null);
        cursor.moveToFirst();
        int idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
        return cursor.getString(idx);
    }
}
