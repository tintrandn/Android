package recruit.co.jp.moviestore.fragment;

import java.util.ArrayList;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import recruit.co.jp.moviestore.R;
import recruit.co.jp.moviestore.model.Movie;
import recruit.co.jp.moviestore.network.api.JSonParse;
import recruit.co.jp.moviestore.view.adapter.GridViewMovieAdapter;
import recruit.co.jp.moviestore.view.adapter.ListViewMovieAdapter;

/**
 * Created by TinTHT on 2017/05/17.
 */

public class FragmentMovieList extends Fragment implements ListViewMovieAdapter.ICallback {
    private String TAG = "MovieList";
    private boolean show_Grid = false;
    private boolean load_More = false;
    private RecyclerView mrecyclerListView;
    private RecyclerView mrecyclerGridView;
    private SwipeRefreshLayout listSwipe;
    private SwipeRefreshLayout gridSwipe;
    private LinearLayoutManager mLayoutManagerList;
    private GridLayoutManager mLayoutManagerGrid;
    private ListViewMovieAdapter mListViewAdapter;
    private GridViewMovieAdapter mGridViewAdapter;
    private JSonParse.Page page;
    private Callback mCallback;
    private ArrayList<Movie> mMovieArrayList;
    private static final int SPAN_COUNT = 2;
    private static int pageNumber = 1;

//    public FragmentMovieList(Callback mCallback) {
//        this.mCallback = mCallback;
//    }

    //===============================================================
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }
    //===============================================================
    private void loadData() {
        new MyAsyncTask().execute();
    }
    //===============================================================

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_movie_list, container, false);
        mrecyclerListView = (RecyclerView)v.findViewById(R.id.recycle_list);
        mrecyclerGridView = (RecyclerView)v.findViewById(R.id.recycle_grid);

        listSwipe = (SwipeRefreshLayout) v.findViewById(R.id.list_swipe_refresh);
        gridSwipe = (SwipeRefreshLayout) v.findViewById(R.id.grid_swipe_refresh);
        mrecyclerListView.setHasFixedSize(true);
        mrecyclerGridView.setHasFixedSize(true);
        // use a linear layout manager
        mLayoutManagerList = new LinearLayoutManager(getActivity());
        mrecyclerListView.setLayoutManager(mLayoutManagerList);
        //use a grid layout manager
        mLayoutManagerGrid = new GridLayoutManager(getActivity(),SPAN_COUNT);
        mrecyclerGridView.setLayoutManager(mLayoutManagerGrid);
        //implements loadmore function
        mrecyclerListView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            int pos;
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                pos = mLayoutManagerList.findLastCompletelyVisibleItemPosition();
                if(pos == mMovieArrayList.size()-1) {
                    Log.d("...", "Last Item Now !");
                    //Do pagination.. i.e. fetch new data
                    loadMore();
                }
                super.onScrolled(recyclerView, dx, dy);
            }
        });

        mrecyclerGridView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            int pos;
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                pos = mLayoutManagerGrid.findLastCompletelyVisibleItemPosition();
                if(pos == mMovieArrayList.size()-1) {
                    Log.d("...", "Last Item Now !");
                    //Do pagination.. i.e. fetch new data
                    loadMore();
                }
                super.onScrolled(recyclerView, dx, dy);
            }
        });
        //run async task to load data and set list view or grid view
        loadData();

        //===========================================================================
        //refresh listener
        listSwipe.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                refreshData();
            }

        });

        // Configure the refreshing colors
        listSwipe.setColorSchemeResources(android.R.color.holo_blue_bright,
                android.R.color.holo_green_light,
                android.R.color.holo_orange_light,
                android.R.color.holo_red_light);

        gridSwipe.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                refreshData();
            }
        });

        // Configure the refreshing colors
        gridSwipe.setColorSchemeResources(android.R.color.holo_blue_bright,
                android.R.color.holo_green_light,
                android.R.color.holo_orange_light,
                android.R.color.holo_red_light);

        return v;
    }
    //refresh data
    private void refreshData() {
        Log.d(TAG,"refresh");
        mMovieArrayList.clear();
        pageNumber = 1;
        loadData();
    }

    //loadmore data
    private void loadMore() {
        load_More = true;
        loadData();
        Log.d(TAG,"loadmore pagenumber:" +String.valueOf(pageNumber));
    }


    //===============================================================
    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        MenuItem show = menu.findItem(R.id.action_show);
        show.setVisible(true);
    }
    //===============================================================
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        //noinspection SimplifiableIfStatement
        if (id == R.id.action_show) {
            if (!show_Grid) {
                // Show grid view
                show_Grid = true;
                item.setIcon(R.mipmap.ic_list_white);
                gridSwipe.setVisibility(View.VISIBLE);
                listSwipe.setVisibility(View.GONE);
                Log.d(TAG,"List show");
            } else {
                // Show list view
                show_Grid = false;
                gridSwipe.setVisibility(View.GONE);
                listSwipe.setVisibility(View.VISIBLE);
                item.setIcon(R.mipmap.ic_grid_on_white);
                Log.d(TAG,"Grid show");
            }
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void clickItem(int position) {
        Log.d("TAG:"+FragmentMovieList.class.getName(),"clickItem "+ position);
        mCallback.clickItem(position);
    }

    //load data and init recycle view
    private class MyAsyncTask extends AsyncTask<String,String,String>{

        public MyAsyncTask() {

        }

        @Override
        protected String doInBackground(String... params) {
            JSonParse jsonParse = new JSonParse();
            if (load_More){
                pageNumber++;
            }
            page = jsonParse.startParse_Popular(String.valueOf(pageNumber));
            Log.d(TAG,"Start parse pagenumber:" +String.valueOf(pageNumber));
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            //init data
            if (mMovieArrayList == null){
                Log.d(TAG,"1st parsing..");
            mMovieArrayList = page.get_movieList();
            }
            else {
                Log.d(TAG,"Adding new movie from load more");
                ArrayList<Movie> movielist = page.get_movieList();
                for (Movie m:movielist)
                    mMovieArrayList.add(m);
            }
            if (load_More){
                mListViewAdapter.notifyDataSetChanged();
                mGridViewAdapter.notifyDataSetChanged();
                load_More = false;
            }else {
                // specify an adapter
                mListViewAdapter = new ListViewMovieAdapter(mMovieArrayList,FragmentMovieList.this);
                mGridViewAdapter = new GridViewMovieAdapter(mMovieArrayList);
                mrecyclerListView.setAdapter(mListViewAdapter);
                mrecyclerGridView.setAdapter(mGridViewAdapter);
            }
            listSwipe.setRefreshing(false);
            gridSwipe.setRefreshing(false);
        }
    }
    //call back
    public interface Callback{
        void clickItem(int position);
    }
}
