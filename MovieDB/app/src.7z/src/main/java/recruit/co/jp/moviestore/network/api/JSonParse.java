package recruit.co.jp.moviestore.network.api;

import android.os.Environment;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Authenticator;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.PasswordAuthentication;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;

import recruit.co.jp.moviestore.model.Cast;
import recruit.co.jp.moviestore.model.Movie;


/**
 * Created by TinTHT on 2017/05/24.
 */

public class JSonParse {
    /*API formated:
     *URL to get movies JSON
     *api.themoviedb.org/3/movie/popular?api_key=e7631ffcb8e766993e5ec0c1f4245f93&page={pageNumber}
     */
    private static final String API_KEY = "api_key=e7631ffcb8e766993e5ec0c1f4245f93&page=";//{pageNumber}
    private static final String API_BASE = "http://api.themoviedb.org/3/configuration?";
    private static final String API_MOVIE_LIST_POPULAR = "http://api.themoviedb.org/3/movie/popular?";
    private static final String API_MOVIE_LIST_TOP_RATE = "http://api.themoviedb.org/3/movie/top_rated?";
    private static final String API_MOVIE_LIST_UPCOMING = "http://api.themoviedb.org/3/movie/upcoming?";
    private static final String API_MOVIE_LIST_NOW_PLAYING = "http://api.themoviedb.org/3/now_playing?";
    private static final String API_MOVIE_DESTAIL = "http://api.themoviedb.org/3/movie/";//{movieId}?api_key=e7631ffcb8e766993e5ec0c1f4245f93
    private static final String API_CAST = "api.themoviedb.org/3/movie/";//{movieId}/credits?api_key=e7631ffcb8e766993e5ec0c1f4245f93"

    // JSON Node Movie
    private static final String MOVIE_IMAGE = "poster_path";
    private static final String MOVIE_TITLE = "title";
    private static final String RELEASE_DAY = "release_date";
    private static final String MOVIE_RATE = "vote_count";
    private static final String MOVIE_OVERVIEW = "overview";
    private static final String MOVIE_ID = "id";
    private static final String MOVIE_ADULT = "adult";

    // JSON Node Case
    private static final String CAST_IMAGE = "profile_path";
    private static final String CAST_NAME = "name";


    private static final String TAG = "JsonParse";

    public JSonParse(){

    }
    //=====================================================================
    protected static String readUrl(String urlString) throws Exception {
        BufferedReader reader = null;
        try {
//            Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("10.0.0.1", 8080));
//            URLConnection url = new URL(urlString).openConnection(proxy);
////            Authenticator authenticator = new Authenticator() {
////
////                public PasswordAuthentication getPasswordAuthentication() {
////                    return (new PasswordAuthentication("tintht",
////                            "X@thu1mat".toCharArray()));
////                }
////            };
////            Authenticator.setDefault(authenticator);
//            Authenticator.setDefault(new Authenticator() {
//                protected PasswordAuthentication getPasswordAuthentication() {
//                    return new PasswordAuthentication("fdnproxy.fsoft.fpt.vn\\tintht", "X@thu1mat".toCharArray());
//                }
//            });

        URL url = new URL(urlString);
//            reader = new BufferedReader (new InputStreamReader(url.getInputStream()));
        reader = new BufferedReader(new InputStreamReader(url.openStream()));
            StringBuffer buffer = new StringBuffer();
            int read;
            char[] chars = new char[1024];
            while ((read = reader.read(chars)) != -1)
                buffer.append(chars, 0, read);
            Log.d(TAG,buffer.toString());
            return buffer.toString();
        } finally {
            if (reader != null)
                reader.close();
        }
    }
    //=====================================================================
    protected static String readFile(String file_Name) throws Exception {
        File sdcard = Environment.getExternalStorageDirectory();
//Get the text file
        File file = new File(sdcard,file_Name);
//Read text from file
        StringBuilder json = new StringBuilder();
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;

            while ((line = br.readLine()) != null) {
                json.append(line);
                json.append('\n');
            }
            br.close();
        }
        catch (IOException e) {
            //You'll need to add proper error handling here
        }
        return json.toString();
    }
    //=====================================================================
    public static Page startParse_Popular(String page){
        String json = null;
        String mPage = page;
        try {
            Log.d(TAG,"Read from api");
//            json = readUrl("http://api.themoviedb.org/3/movie/popular?api_key=e7631ffcb8e766993e5ec0c1f4245f93&page="+mPage);
            json = readUrl(API_MOVIE_LIST_POPULAR+API_KEY+mPage);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (json == null){
            try{
                Log.d(TAG,"Read local file");
                json = readFile("page_"+mPage+".txt");
            }
            catch (Exception e){
                e.printStackTrace();
            }
        }
        Log.d(TAG,json);
        Gson gson = new Gson();
        Page db_page = gson.fromJson(json, Page.class);
        return db_page;
    }
    //=====================================================================
    public static Page startParse_Top_Rate(String page){
        String json = null;
        String mPage = page;
        try {
            Log.d(TAG,"Read from api");
//            json = readUrl("http://api.themoviedb.org/3/movie/popular?api_key=e7631ffcb8e766993e5ec0c1f4245f93&page="+mPage);
            json = readUrl(API_MOVIE_LIST_TOP_RATE+API_KEY+mPage);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (json == null){
            try{
                Log.d(TAG,"Read local file");
                json = readFile("page_"+mPage+".txt");
            }
            catch (Exception e){
                e.printStackTrace();
            }
        }
//        Log.d(TAG,json);
        Gson gson = new Gson();
        Page db_page = gson.fromJson(json, Page.class);
        return db_page;
    }
    //=====================================================================
    public static Page startParse_Upcoming(String page){
        String json = null;
        String mPage = page;
        try {
            Log.d(TAG,"Read from api");
//            json = readUrl("http://api.themoviedb.org/3/movie/popular?api_key=e7631ffcb8e766993e5ec0c1f4245f93&page="+mPage);
            json = readUrl(API_MOVIE_LIST_UPCOMING+API_KEY+mPage);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (json == null){
            try{
                Log.d(TAG,"Read local file");
                json = readFile("page_"+mPage+".txt");
            }
            catch (Exception e){
                e.printStackTrace();
            }
        }
//        Log.d(TAG,json);
        Gson gson = new Gson();
        Page db_page = gson.fromJson(json, Page.class);
        return db_page;
    }
    //=====================================================================
    public static Page startParse_Now_Playing(String page){
        String json = null;
        String mPage = page;
        try {
            Log.d(TAG,"Read from api");
//            json = readUrl("http://api.themoviedb.org/3/movie/popular?api_key=e7631ffcb8e766993e5ec0c1f4245f93&page="+mPage);
            json = readUrl(API_MOVIE_LIST_NOW_PLAYING+API_KEY+mPage);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (json == null){
            try{
                Log.d(TAG,"Read local file");
                json = readFile("page_"+mPage+".txt");
            }
            catch (Exception e){
                e.printStackTrace();
            }
        }
//        Log.d(TAG,json);
        Gson gson = new Gson();
        Page db_page = gson.fromJson(json, Page.class);
        return db_page;
    }

    //=====================================================================
    public static Cast_Id startParse_Cast(String movieID){
        String json = null;
        try {
            Log.d(TAG,"Read from api");

            json = readUrl(API_CAST+movieID+"/credits?"+API_KEY);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (json == null){
            try{
                Log.d(TAG,"Read local file");
                json = readFile("page_cast.txt");
            }
            catch (Exception e){
                e.printStackTrace();
            }
        }
//        Log.d(TAG,json);
        Gson gson = new Gson();
        Cast_Id db_cast = gson.fromJson(json, Cast_Id.class);
        return db_cast;
    }
    //=====================================================================
    public class Cast_Id {
        @SerializedName("id")
        private int id;
        @SerializedName("cast")
        private ArrayList<Cast> mCastArrayList;

        public ArrayList<Cast> getmCastArrayList() {
            return mCastArrayList;
        }

        public void setmCastArrayList(ArrayList<Cast> mCastArrayList) {
            this.mCastArrayList = mCastArrayList;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

    }
    //=====================================================================
    public class Page {
        @SerializedName("page")
        private int page_number;

        public int getPage_number() {
            return page_number;
        }

        public void setPage_number(int page_number) {
            this.page_number = page_number;
        }

        @SerializedName("results")

        private ArrayList<Movie> movieList;

        public ArrayList <Movie> get_movieList(){
            return movieList;
        }
    }
}
