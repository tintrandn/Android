package recruit.co.jp.moviestore.util;

/**
 * Created by TinTHT on 2017/06/06.
 */

import android.content.Context;
import android.util.Log;

import com.android.volley.Network;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HttpStack;
import com.android.volley.toolbox.HurlStack;

import java.io.File;

/**
 * Created by TIN TRAN on 05-Jun-17.
 */

public class CustomRequestQueue {
    // Default maximum disk usage in bytes
    private static final int DEFAULT_DISK_USAGE_BYTES = 25 * 1024 * 1024;

    // Default cache folder name
    private static final String DEFAULT_CACHE_DIR = "photos";

    private static Context mContext;

    public CustomRequestQueue(Context context) {
        this.mContext = context;
    }

    //=======================================================
    public static RequestQueue getRequestQueue(){
        // define cache folder
        File rootCache = mContext.getExternalCacheDir();
        if (rootCache == null) {
            Log.d("RequestQueue","Can't find External Cache Dir, "
                    + "switching to application specific cache directory");
            rootCache = mContext.getCacheDir();
        }
        Log.d("Cache path ",rootCache.getPath()+DEFAULT_CACHE_DIR);
        File cacheDir = new File(rootCache, DEFAULT_CACHE_DIR);
        cacheDir.mkdirs();

        HttpStack stack = new HurlStack();
        Network network = new BasicNetwork(stack);
        DiskBasedCache diskBasedCache = new DiskBasedCache(cacheDir, DEFAULT_DISK_USAGE_BYTES);
        RequestQueue queue = new RequestQueue(diskBasedCache, network);
        queue.start();
        return queue;
    }
}

