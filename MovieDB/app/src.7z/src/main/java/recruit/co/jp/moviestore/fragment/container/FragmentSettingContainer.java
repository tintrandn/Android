package recruit.co.jp.moviestore.fragment.container;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import recruit.co.jp.moviestore.R;
import recruit.co.jp.moviestore.fragment.FragmentMovieDetail;
import recruit.co.jp.moviestore.fragment.FragmentRemindShowAll;
import recruit.co.jp.moviestore.fragment.FragmentSetting;

/**
 * Created by TinTHT on 2017/06/07.
 */

public class FragmentSettingContainer extends Fragment {
    private String TAG = "Setting";
    private FragmentManager mFragmentManager;
    private FragmentTransaction mFragmentTransaction;
    private static final String SHOW_ALL_REMIND = "recruit.co.jp.moviestore.SHOW_ALL_REMIND";
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_movie_container,container,false);
        FragmentSetting firstFragment = new FragmentSetting();
        mFragmentManager = getChildFragmentManager();
        mFragmentTransaction = mFragmentManager.beginTransaction();
        mFragmentTransaction.add(R.id.fragment_container, firstFragment).commit();
        return v;
    }

    private BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Log.d(TAG,"Receiver broadcast" + SHOW_ALL_REMIND);

            FragmentRemindShowAll secondFragment = new FragmentRemindShowAll("All Reminds");
            mFragmentTransaction = mFragmentManager.beginTransaction();
            mFragmentTransaction.replace(R.id.fragment_container, secondFragment);
            mFragmentTransaction.addToBackStack(null);
            // Commit the transaction
            mFragmentTransaction.commit();
        }
    };

    @Override
    public void onDetach() {
        super.onDetach();
        if (receiver != null)
            getActivity().unregisterReceiver(receiver);
        receiver = null;
    }

    @Override
    public void onResume() {
        super.onResume();
        IntentFilter filter = new IntentFilter();
        filter.addAction(SHOW_ALL_REMIND);
        getActivity().registerReceiver(receiver, filter);
    }
}
