package recruit.co.jp.moviestore.model.storage.entity;

/**
 * Created by TinTHT on 2017/06/07.
 */

public class Remind {
    public String _id;

    public Remind(String _id, String remind_name, String remind_time) {
        this._id = _id;
        this.remind_name = remind_name;
        this.remind_time = remind_time;
    }

    public String remind_name;
    public String remind_time;


    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public Remind(String remind_name, String remind_time) {
        this.remind_name = remind_name;

        this.remind_time = remind_time;
    }

    public String getRemind_name() {
        return remind_name;
    }

    public void setRemind_name(String remind_name) {
        this.remind_name = remind_name;
    }

    public String getRemind_time() {
        return remind_time;
    }

    public void setRemind_time(String remind_time) {
        this.remind_time = remind_time;
    }
}
